_________________HYD__________________
insert into roomdetails values(100,'1001','101',
'AC-Standard room',1500,'T','');

insert into roomdetails values(100,'1002','102',
'Non-AC Standard room',900,'T','');

insert into roomdetails values(100,'1003','103',
'AC executive room',2500,'F','');

insert into roomdetails values(100,'1004','104',
'AC presidential room',3500,'F','');


insert into roomdetails values(100,'1005','105',
'AC Suite room',3500,'T','');

----
insert into roomdetails values(101,'101101','101',
'AC-Standard room',2500,'T','');

insert into roomdetails values(101,'101102','102',
'Non-AC room',1000,'F','');

insert into roomdetails values(101,'101103','103',
'Royal room',4000,'F','');


insert into roomdetails values(101,'101104','104',
'Suite Room',6000,'T','');


insert into roomdetails values(101,'101105','105',
'Business Room',5000,'T','');

----

insert into roomdetails values(102,'102101','101',
'AC room',3500,'T','');

insert into roomdetails values(102,'102102','102',
'Non-AC room',1500,'F','');

insert into roomdetails values(102,'102103','103',
'Deluxe room',3500,'T','');


insert into roomdetails values(102,'102104','104',
'Emirate Room',7000,'F','');


insert into roomdetails values(102,'102105','105',
'Business Room',9000,'T','');


insert into roomdetails values(102,'102106','106',
'Suite Room',9000,'T','');

---
insert into roomdetails values(103,'103101','101',
'Single room',500,'F','');

insert into roomdetails values(103,'103102','102',
'AC room',1500,'F','');

insert into roomdetails values(103,'103103','103',
'Deluxe room',3500,'T','');


insert into roomdetails values(103,'103104','104',
'Suite Room',6000,'T','');


insert into roomdetails values(103,'103105','105',
'Business Room',800,'T','');
---
insert into roomdetails values(104,'104101','101',
'Non-AC room',999,'T','');

insert into roomdetails values(104,'104102','102',
'AC room',1500,'T','');

insert into roomdetails values(104,'104103','103',
'Royale room',2960,'F','');


insert into roomdetails values(104,'104104','104',
'Suite Room',7520,'F','');


insert into roomdetails values(104,'104105','105',
'Business Room',6000,'T','');

____________________BANGALORE___________________________

insert into roomdetails values(105,'105101','101',
'Standard room',1500,'T','');

insert into roomdetails values(105,'105102','102',
'AC Standard room',900,'T','');

insert into roomdetails values(105,'105103','103',
'AC executive room',2500,'F','');

insert into roomdetails values(105,'105104','104',
'AC presidential room',3500,'F','');


insert into roomdetails values(105,'105105','105',
'AC Suite room',3500,'T','');

----
insert into roomdetails values(106,'106101','101',
'Standard room',1500,'T','');

insert into roomdetails values(106,'106102','102',
'AC Standard room',2000,'T','');

insert into roomdetails values(106,'106103','103',
'AC executive room',3550,'F','');

insert into roomdetails values(106,'106104','104',
'AC Royal room',20000,'F','');


insert into roomdetails values(106,'106105','105',
'AC Emirate room',35000,'T','');
-------
insert into roomdetails values(107,'107101','101',
'Exotic room',2000,'T','');

insert into roomdetails values(107,'107102','102',
'Clarks room',3000,'F','');

insert into roomdetails values(107,'107103','103',
'Clarks Empire room',4050,'F','');

insert into roomdetails values(107,'107104','104',
'Zenith room',5500,'T','');


insert into roomdetails values(107,'107105','105',
'United Suite room',9000,'T','');
----
insert into roomdetails values(108,'108101','101',
'Exotic room',2000,'T','');

insert into roomdetails values(108,'108102','102',
'Zuri room',3000,'T','');

insert into roomdetails values(108,'108103','103',
'Field Empire room',4050,'F','');

insert into roomdetails values(108,'108104','104',
'Zuri Empire room',5500,'T','');


insert into roomdetails values(108,'108105','105',
'Suite room',9000,'F','');
-----
insert into roomdetails values(109,'109101','101',
'Non AC room',900,'F','');

insert into roomdetails values(109,'109102','102',
'AC room',2000,'F','');

insert into roomdetails values(109,'109103','103',
'Royal Empire room',3650,'T','');

insert into roomdetails values(109,'109104','104',
'Suite Empire room',4523,'F','');


insert into roomdetails values(109,'109105','105',
'United room',7854,'T','');

_________________CHENNAI___________________________

insert into roomdetails values(110,'110101','101',
'SRM Standard room',1256,'F','');

insert into roomdetails values(110,'110102','102',
'SRM AC Standard room',2356,'T','');

insert into roomdetails values(110,'110103','103',
'SRM executive room',4586,'F','');

insert into roomdetails values(110,'110104','104',
'AC presidential room',6985,'T','');


insert into roomdetails values(110,'110105','105',
'SRM AC Suite room',8966,'T','');
--------------
insert into roomdetails values(111,'1111','101',
'Non AC room',900,'F','');

insert into roomdetails values(111,'1112','102',
'AC Standard room',1355,'F','');

insert into roomdetails values(111,'1113','103',
'executive room',2564,'T','');

insert into roomdetails values(111,'1114','104',
'Royal room',4545,'T','');


insert into roomdetails values(111,'1115','105',
'Suite room',8989,'T','');
-------
insert into roomdetails values(112,'112101','101',
'Non AC room',900,'F','');

insert into roomdetails values(112,'112102','102',
'AC Standard room',1355,'T','');

insert into roomdetails values(112,'112103','103',
'executive room',2564,'T','');

insert into roomdetails values(112,'112104','104',
'Royal room',4545,'T','');


insert into roomdetails values(112,'112105','105',
'Suite room',8989,'F','');

-----------

insert into roomdetails values(113,'113101','101',
'AC room',800,'T','');

insert into roomdetails values(113,'113102','102',
'AC Standard room',1100,'F','');

insert into roomdetails values(113,'113103','103',
'executive room',2144,'T','');

insert into roomdetails values(113,'113104','104',
'Royal room',3546,'T','');


insert into roomdetails values(113,'113105','105',
'Emirates room',4565,'T','');
-----
insert into roomdetails values(114,'114101','101',
'accord AC room',266,'T','');

insert into roomdetails values(114,'114102','102',
'Accord Standard room',200,'F','');

insert into roomdetails values(114,'114103','103',
'executive room',564,'T','');

insert into roomdetails values(114,'114104','104',
'Royal room',3534,'T','');


insert into roomdetails values(114,'114105','105',
'Suite room',4554,'T','');

__________________DELHI______________________
insert into roomdetails values(115,'115101','101',
'nataraj AC room',1235,'T','');

insert into roomdetails values(115,'115102','102',
'nataraj Standard room',2541,'F','');

insert into roomdetails values(115,'115103','103',
'united room',3564,'T','');

insert into roomdetails values(115,'115104','104',
'Royal room',4523,'T','');


insert into roomdetails values(115,'115105','105',
'Emirate room',5254,'T','');
-----
insert into roomdetails values(116,'116101','101',
' AC room',1200,'T','');

insert into roomdetails values(116,'116102','102',
'AC Standard room',2400,'T','');

insert into roomdetails values(116,'116103','103',
'Royal room',3600,'F','');

insert into roomdetails values(116,'116104','104',
'United room',4800,'T','');


insert into roomdetails values(116,'116105','105',
'Supreme room',6000,'F','');
-------
insert into roomdetails values(117,'117101','101',
'NOn AC room',800,'F','');

insert into roomdetails values(117,'117102','102',
'AC room',1600,'T','');

insert into roomdetails values(117,'117103','103',
'Royal room',2400,'T','');

insert into roomdetails values(117,'117104','104',
'Luxury room',3200,'F','');


insert into roomdetails values(117,'117105','105',
'Supreme room',4000,'T','');

-------------
insert into roomdetails values(118,'118101','101',
'NOn AC room',1200,'F','');

insert into roomdetails values(118,'118102','102',
'AC room',2400,'T','');

insert into roomdetails values(118,'118103','103',
'Royal room',3600,'F','');

insert into roomdetails values(118,'118104','104',
'Luxury room',4800,'T','');


insert into roomdetails values(118,'118105','105',
'Supreme room',6000,'F','');
----------
insert into roomdetails values(119,'119101','101',
'NOn AC room',100,'T','');

insert into roomdetails values(119,'119102','102',
'AC room',200,'T','');

insert into roomdetails values(119,'119103','103',
'Presidential room',400,'F','');

insert into roomdetails values(119,'119104','104',
'Luxury room',800,'T','');


insert into roomdetails values(119,'119105','105',
'Emirate room',1600,'T','');

____________________MUMBAI________________________

insert into roomdetails values(120,'120101','101',
'NOn AC room',100,'T','');

insert into roomdetails values(120,'120102','102',
'AC room',200,'T','');

insert into roomdetails values(120,'120103','103',
'Presidential room',400,'F','');

insert into roomdetails values(120,'120104','104',
'Luxury room',800,'T','');


insert into roomdetails values(120,'120105','105',
'Emirate room',1600,'T','');

--------------------
insert into roomdetails values(121,'121101','101',
'NOn AC room',400,'T','');

insert into roomdetails values(121,'121102','102',
'AC room',800,'F','');

insert into roomdetails values(121,'121103','103',
'Presidential room',1200,'F','');

insert into roomdetails values(121,'121104','104',
'Luxury room',1600,'F','');


insert into roomdetails values(121,'121105','105',
'Emirate room',2000,'T','');

--------------

insert into roomdetails values(122,'122101','101',
'NOn AC room',800,'T','');

insert into roomdetails values(122,'122102','102',
'AC room',1200,'F','');

insert into roomdetails values(122,'122103','103',
'Presidential room',1250,'F','');

insert into roomdetails values(122,'122104','104',
'Luxury room',2300,'F','');


insert into roomdetails values(122,'122105','105',
'Emirate room',4600,'F','');

-----------

insert into roomdetails values(123,'123101','101',
'NOn AC room',800,'F','');

insert into roomdetails values(123,'123102','102',
'AC room',1200,'T','');

insert into roomdetails values(123,'123103','103',
'Presidential room',1250,'F','');

insert into roomdetails values(123,'123104','104',
'Luxury room',2300,'T','');


insert into roomdetails values(123,'123105','105',
'Emirate room',4600,'T','');

-----------

insert into roomdetails values(124,'124101','101',
'AC room',700,'T','');

insert into roomdetails values(124,'124102','102',
'AC Ultra room',1400,'F','');

insert into roomdetails values(124,'124103','103',
'Presidential room',2100,'T','');

insert into roomdetails values(124,'124104','104',
'Luxury Suite room',2800,'F','');


insert into roomdetails values(124,'124105','105',
'Emirate United room',3500,'T','');



