_________________________HYDERABAD__________________________

insert into hotels values(hotel_seq.nextval,'HYDERABAD','Taj Deccan',
'Banjara Hills','Set within gardens',0,'0403939','0403939',
4.9,'tajdeccan@gmail.com','');


insert into hotels values(hotel_seq.nextval,'HYDERABAD','Hyatt',
'Banjara Hills','7 km from NTR Gardens',0,'1234','1234',
4.8,'hyatt@gmail.comm','4949');


insert into hotels values(hotel_seq.nextval,'HYDERABAD','Trident',
'Madhapur','15-minute walk from the Nizam Museum',0,'2323','2323',
4.5,'trident@gmail.com','2323');


insert into hotels values(hotel_seq.nextval,'HYDERABAD','ITC Kakatiya',
'Begumpet','Overlooking Hussain Sagar lake',0,'0132','0132',
5,'itckakatiya@gmail.com','0132');


insert into hotels values(hotel_seq.nextval,'HYDERABAD','Sheraton',
'Gachibowli','Opposite to Capgemini',0,'1111','1111',
4,'sheraton@gmail.com','1111');

________________________BANGALORE_____________________________

insert into hotels values(hotel_seq.nextval,'BANGALORE','Welcom Hotel',
'Gulmarg','2.2 km to City centre',0,'223322','223322',
4,'welcom@gmail.com','223322');

insert into hotels values(hotel_seq.nextval,'BANGALORE','The Oberoi',
'Mahatma Gandhi Road','posh hotel with tropical gardens',0,'123112','123112',
4.2,'oberoi@gmail.com','123112');

insert into hotels values(hotel_seq.nextval,'BANGALORE','Clarks Exotica',
'Sadahalli Post','Nestled in the Nandi Hills',0,'235654','235654',
4.6,'clarksexotica@gmail.com','235654');

insert into hotels values(hotel_seq.nextval,'BANGALORE','Zuri Whitefield',
'Whitefield','1.3 km from International Technology',0,'145879','145879',
3.8,'zuriwhitefield@gamil.com','145879');

insert into hotels values(hotel_seq.nextval,'BANGALORE','Chancry Pavilion',
'Residency Road','Set 3 minutes walk from the Bangalore Club',0,'2561466','2561466',
3.9,'chancarypavilion@gmail.com','2561466');

__________________________CHENNAI____________________________

insert into hotels values(hotel_seq.nextval,'CHENNAI','SRM Hotel',
'GST Road Chennai','Near to Railway station',0,'2563145','2563145',
3.5,'srm@gmail.com','2563145');


insert into hotels values(hotel_seq.nextval,'CHENNAI','Raintree',
'Teynampet','modern business hotel is 2.7 km from Mambalam railway station',0,'841515','841515',
4.2,'raintree@gmail.com','841515');

insert into hotels values(hotel_seq.nextval,'CHENNAI','Woodland',
'Mylapore','Set in Chennai buzzing Mylapore district',0,'960515','960515',
5,'woodland@gmail.com','960515');

insert into hotels values(hotel_seq.nextval,'CHENNAI','Somerset',
'MRC Nagar','3.1 km from the Madras Lighthouse',0,'651562','651562',
4.1,'somerset@gmail.com','651562');

insert into hotels values(hotel_seq.nextval,'CHENNAI','Accord',
'T Nagar','1.5 km from Valluvar Kottam monument',0,'8541451','8541451',
3.9,'accord@gmail.com','8541451');



_________________________DELHI_______________________________

insert into hotels values(hotel_seq.nextval,'DELHI','Nataraj Hotel',
'Pahar Ganj','3-minute walk from Ramakrishna Ashram Marg metro station',0,'1532052','1532052',
5,'nataraj@gmail.com','1532052');

insert into hotels values(hotel_seq.nextval,'DELHI','Shangri',
'Connaught Place','sophisticated high-rise hotel',0,'151315','151315',
3,'shangri@gmail.com','151315');

insert into hotels values(hotel_seq.nextval,'DELHI','Red Fox',
'IGI Airport','3 km from the Indira Gandhi International Airport',0,'13251686','13251686',
5,'redfox@gmail.com','13251686');

insert into hotels values(hotel_seq.nextval,'DELHI','imperial',
'Paschim Vihar','1.3 km from Jwala Heri open-air market',0,'1525613','1525613',
2.9,'imperial@gmail.com','1525613');

insert into hotels values(hotel_seq.nextval,'DELHI','Radisson',
'Janpath Lane','luxe landmark hotel',0,'1565651','1565651',
2.9,'radisson@gmail.com','1565651');

__________________________MUMBAI_____________________________

insert into hotels values(hotel_seq.nextval,'MUMBAI','Leela Hotel',
'Andheri East','7-minute walk from a metro station',0,'964754','964754',
5,'leela@gmail.com','964754');

insert into hotels values(hotel_seq.nextval,'MUMBAI','Sofitel',
'Bandra Kurla Complex Bandra East ','luxe hotel is 7.2 km from Chhatrapati Shivaji International Airport',0,'951512','951512',
4.9,'sofitel@gamil.com','951512');

insert into hotels values(hotel_seq.nextval,'MUMBAI','Orchid',
'Vile Parle (E) ','Set 1.3 km from Ville Parle railway station',0,'962151','962151',
4.8,'orchid@gmail.com','962151');

insert into hotels values(hotel_seq.nextval,'MUMBAI','Novatel',
'Balraj Sahani Marg, Juhu Beach ','Set within a 9-minute walk of 2 bus stops',0,'974554','974554',
4.7,'novatel@gmail.com','974554');

insert into hotels values(hotel_seq.nextval,'MUMBAI','Marriot',
'Juhu Tara Road, Mumbai, Juhu Beach ','this upscale hotel is 7 km from Chhatrapati Shivaji International Airport Mumbai',0,'932452','932452',
4.6,'marriot@gmail.com','932452');
