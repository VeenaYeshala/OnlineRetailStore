package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.util.DbUtil;

public class HBMSDaoImpl implements HBMSDao{
	
	Connection con=null;
	PreparedStatement stat=null;
	Statement s=null;
	@Override
	public int registerUsers(Users users) throws HBMSException {
		con =DbUtil.getConnection();
	
		
		try {
			s=con.createStatement();
			ResultSet rs =  s.executeQuery("SELECT USERS_SEQ.nextval from dual");
			rs.next();
			int userId = rs.getInt(1);
			stat=con.prepareStatement("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)");
			stat.setInt(1, userId);
			stat.setString(2, users.getPassword());
			stat.setString(3, users.getRole());
			stat.setString(4, users.getUserName());
			stat.setString(5, users.getMobileNo());
			stat.setString(6, users.getPhone());
			stat.setString(7, users.getAddress());
			stat.setString(8, users.getEmail());
			
			return stat.executeUpdate();
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
		
	}
	@Override
	public boolean validateLogin(UserBean user) throws HBMSException {
		con =DbUtil.getConnection();
		String userName=user.getUserName();
		String password=user.getPassword();
		boolean result = false;
		String query = "SELECT * FROM users WHERE user_name=? and password=?";
		
		try {
		
			stat = con.prepareStatement(query);
			
			
			stat.setString(1, userName);
			stat.setString(2, password);
			
		
			ResultSet rst = stat.executeQuery();
			
			while(rst.next()){
				
				result = true;
			}
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
		
		return result;
		
	}
	@Override
	public List<Hotels> getHotels(String city) throws HBMSException {
		List<Hotels> hotelList = new ArrayList<Hotels>();
		con=DbUtil.getConnection();
		try {
			stat=con.prepareStatement("SELECT * FROM hotels WHERE city=?");
			stat.setString(1, city);
			ResultSet rs=stat.executeQuery();
			while(rs.next()) {
				Hotels hotels=new Hotels();
			
				hotels.setHotelId(rs.getInt(1));
				hotels.setCity(rs.getString(2));
				hotels.setHotelName(rs.getString(3));
				hotels.setAddress(rs.getString(4));
				hotels.setDescription(rs.getString(5));
				hotels.setArpn(rs.getFloat(6));
				hotels.setPhoneNum1(rs.getString(7));
				hotels.setPhoneNum2(rs.getString(8));
				hotels.setRating(rs.getInt(9));
				hotels.setEmail(rs.getString(10));
				hotels.setFax(rs.getString(11));
				hotelList.add(hotels);
			}
			return hotelList;
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
	}
	@Override
	public List<RoomDetails> getRooms(int hotelId) throws HBMSException {
		List<RoomDetails> roomList = new ArrayList<RoomDetails>();
		con=DbUtil.getConnection();
		try {
			stat=con.prepareStatement("SELECT * FROM roomdetails WHERE hotel_id=?");
			stat.setInt(1, hotelId);
			ResultSet rs=stat.executeQuery();
			while(rs.next()) {
				RoomDetails room=new RoomDetails();
				room.setHotelId(rs.getInt(1));
				room.setRoomId(rs.getString(2));
				room.setRoomNo(rs.getString(3));
				room.setRoomType(rs.getString(4));
				room.setPerNightRate(rs.getFloat(5));
				room.setAvailability(rs.getString(6));
				room.setPhoto(rs.getBlob(7));
				roomList.add(room);
				
			}
			return roomList;
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
	}
	//boolean????
	@Override
	public int updateAvailability(String roomId) throws HBMSException {
		con=DbUtil.getConnection();
		List<RoomDetails> roomList=new ArrayList<RoomDetails>();
		try {
			stat=con.prepareStatement("UPDATE roomdetails set availability='F' where room_id=?");
			stat.setString(1, roomId);
			return stat.executeUpdate();
			
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
		
	}
	@Override
	public int getUserId(String userName) throws HBMSException {
		con=DbUtil.getConnection();
		try {
			stat=con.prepareStatement("SELECT user_id FROM users WHERE user_name=?");
			stat.setString(1, userName);
			ResultSet rs=stat.executeQuery();
			rs.next();
			int userId=rs.getInt(1);
			return userId;
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
	}
	@Override
	public int addBookingDetails(BookingDetails bookingDetails) throws HBMSException {
		con=DbUtil.getConnection();
		try {
			s=con.createStatement();
			ResultSet rs =  s.executeQuery("SELECT BOOKINGDETAILS_SEQ.nextval from dual");
			rs.next();
			int bookingId = rs.getInt(1);
			stat=con.prepareStatement("INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)");
			stat.setInt(1, bookingId);
			stat.setString(2, bookingDetails.getRoomId());
			stat.setInt(3, bookingDetails.getUserId());
			stat.setDate(4, Date.valueOf(bookingDetails.getBookedFrom()));
			stat.setDate(5, Date.valueOf(bookingDetails.getBookedTo()));
			stat.setInt(6, bookingDetails.getNoOfAdults());
			stat.setInt(7, bookingDetails.getNoOfChildren());
			stat.setFloat(8, bookingDetails.getAmount());
		return stat.executeUpdate();
	} catch (SQLException e) {
		throw new HBMSException(e.getMessage());
	}

	}
	@Override
	public int getBookingId(String roomId) throws HBMSException {
		con=DbUtil.getConnection();
		try {
			stat=con.prepareStatement("SELECT booking_id FROM bookingdetails WHERE room_id=?");
			stat.setString(1, roomId);
			ResultSet rs=stat.executeQuery();
			rs.next();
			int bookingId=rs.getInt(1);
			return bookingId;
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		}
	}
}
