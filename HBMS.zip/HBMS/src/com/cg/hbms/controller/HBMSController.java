package com.cg.hbms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.HBMSService;
import com.cg.hbms.service.HBMSServiceImpl;

@WebServlet("*.do")
public class HBMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	HBMSService hbmsService=new HBMSServiceImpl();
	RequestDispatcher dispatcher=null;
   
    public HBMSController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String urlPattern=request.getServletPath();
		switch (urlPattern) {
		case "/displayHomePage.do":
			response.sendRedirect("home.jsp");
			break;
		case "/customer.do":
			String role=request.getParameter("role");
			request.getSession().setAttribute("role", role);
			response.sendRedirect("login.jsp");
			break;
		case "/employee.do":
			String r=request.getParameter("role");
			request.getSession().setAttribute("role", r);
			response.sendRedirect("login.jsp");
			break;
		case "/register.do":
			dispatcher=request.getRequestDispatcher("register.jsp");
			dispatcher.forward(request, response);
			
			break;
		case "/addInDb.do":
			Users users=new Users();
			try {
				users.setUserName(request.getParameter("user_name"));
				users.setPassword(request.getParameter("password"));
				users.setMobileNo(request.getParameter("mobile_no"));
				users.setAddress(request.getParameter("address"));
				users.setEmail(request.getParameter("email"));
				users.setPhone(request.getParameter("phone"));
				String role1 = (String) request.getSession().getAttribute("role");
				users.setRole(role1);
				
				
				int result=hbmsService.registerUsers(users);
				if(result==1) {
					dispatcher=request.getRequestDispatcher("login.jsp");
					dispatcher.forward(request, response);
				}
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		case "/search.do":
			String userName=request.getParameter("user_name");
			String password=request.getParameter("password");
			
			UserBean uBean=new UserBean(userName, password);
			Users user=new Users();
			try {
				
				boolean result = hbmsService.validateLogin(uBean);
				int userId=hbmsService.getUserId(userName);
				request.getSession().setAttribute("userId", userId);
				if(result){
					
					
					dispatcher = request.getRequestDispatcher("search.jsp");
					request.getSession().setAttribute("userName", userName);
					dispatcher.forward(request, response);
				}
				
				else{
					
					dispatcher = request.getRequestDispatcher("login.jsp");
					request.getSession().removeAttribute("userName");
					dispatcher.forward(request, response);
					
				}
				
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		case "/location.do":
			String location=request.getParameter("search");
			
			String loc=location.toUpperCase();
			request.getSession().setAttribute("city", loc);
			try {
				List<Hotels> hotels= hbmsService.getHotels(loc);
				dispatcher=request.getRequestDispatcher("listofhotels.jsp");
				request.setAttribute("hotellist", hotels);
				dispatcher.forward(request, response);
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		case "/roomdetails.do":
			int hotelId= Integer.parseInt(request.getParameter("hotelId"));
			
			try {
				List<RoomDetails> rooms=hbmsService.getRooms(hotelId);
				
				request.setAttribute("roomlist", rooms);
				dispatcher=request.getRequestDispatcher("listofrooms.jsp");
				
				dispatcher.forward(request, response);
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		case "/bookNow.do":
			String price=request.getParameter("rate");
			float rate = Float.parseFloat(price);
			request.getSession().setAttribute("price", rate);
			int hotel_Id=Integer.parseInt(request.getParameter("hotelId"));
			request.getSession().setAttribute("hotelId", hotel_Id);
			String roomId=request.getParameter("roomId");
			request.getSession().setAttribute("roomId", roomId);
			int user_id=(int) request.getSession().getAttribute("userId");
			LocalDate localdate=LocalDate.now();
			int date=localdate.getDayOfMonth()+1;
			int month=localdate.getMonthValue();
			int year=localdate.getYear();
			LocalDate local=LocalDate.of(year, month, date);
			request.getSession().setAttribute("localdate", localdate);
			request.getSession().setAttribute("local", local);
			dispatcher=request.getRequestDispatcher("hoteldetails.jsp");
			dispatcher.forward(request, response);
			break;
		case "/addBookingDetails.do":
			BookingDetails bookingDetails = new BookingDetails();
			
			try {
				
				
				String room=(String) request.getSession().getAttribute("roomId");
				bookingDetails.setRoomId(room);
				
				int userid=(int) request.getSession().getAttribute("userId");
				bookingDetails.setUserId(userid);
				
				
				String datefrom= request.getParameter("datefrom");
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate from=LocalDate.parse(datefrom, formatter);
				bookingDetails.setBookedFrom(from);
				
				String dateto=request.getParameter("dateto");
				LocalDate to=LocalDate.parse(dateto, formatter);
				
				bookingDetails.setBookedTo(to);
				int adults=Integer.parseInt(request.getParameter("Adult"));
				bookingDetails.setNoOfAdults(adults);
				int child=Integer.parseInt(request.getParameter("Child"));
				bookingDetails.setNoOfChildren(child);
				
				long daysBetween = ChronoUnit.DAYS.between(from, to);
				float perdayprice=(float) request.getSession().getAttribute("price");
				
				int p=(adults*200)+(child*100);
				float perday=perdayprice+p;
				float total=perday*daysBetween;
				bookingDetails.setAmount(total);
				
				
				int result1=hbmsService.addBookingDetails(bookingDetails);
				
				int res=hbmsService.updateAvailability(room);
				int bookingId=hbmsService.getBookingId(room);
				request.getSession().setAttribute("bookingId", bookingId);
				if(result1==1) {
					dispatcher=request.getRequestDispatcher("success.jsp");
					request.getSession().setAttribute("bookingDetails", bookingDetails);
					dispatcher.forward(request, response);
				}
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;

		default:
			break;
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
