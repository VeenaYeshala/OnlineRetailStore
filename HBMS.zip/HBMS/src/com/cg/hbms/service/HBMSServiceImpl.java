package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dao.HBMSDao;
import com.cg.hbms.dao.HBMSDaoImpl;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;

public class HBMSServiceImpl implements HBMSService {
	
	HBMSDao hbmsDao=new HBMSDaoImpl();
	@Override
	public int registerUsers(Users users) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.registerUsers(users);
	}
	
	@Override
	public boolean validateLogin(UserBean user) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.validateLogin(user);
	}

	@Override
	public List<Hotels> getHotels(String city) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.getHotels(city);
	}

	@Override
	public List<RoomDetails> getRooms(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.getRooms(hotelId);
	}

	@Override
	public int addBookingDetails(BookingDetails bookingDetails)
			throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.addBookingDetails(bookingDetails);
	}

	@Override
	public int getUserId(String userName) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.getUserId(userName);
	}

	@Override
	public int updateAvailability(String roomId) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.updateAvailability(roomId);
	}

	@Override
	public int getBookingId(String roomId) throws HBMSException {
		// TODO Auto-generated method stub
		return hbmsDao.getBookingId(roomId);
	}

}
