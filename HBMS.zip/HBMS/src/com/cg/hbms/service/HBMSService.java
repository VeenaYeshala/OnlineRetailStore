package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;

public interface HBMSService {
	
	int registerUsers(Users users) throws HBMSException;
	boolean validateLogin(UserBean user) throws HBMSException;
	public List<Hotels> getHotels(String city) throws HBMSException;
	public List<RoomDetails> getRooms(int hotelId) throws HBMSException;
	
	public int getUserId(String userName) throws HBMSException;
	int addBookingDetails(BookingDetails bookingDetails) throws HBMSException;
	
	public int updateAvailability(String roomId) throws HBMSException;
	
	public int getBookingId(String roomId) throws HBMSException;
}
