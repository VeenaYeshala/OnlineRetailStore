package com.cg.hbms.dto;

public class Hotels {
	private int hotelId;
	private String city;
	private String hotelName;
	private String address;
	private String description;
	private float arpn;
	private String phoneNum1;
	private String phoneNum2;
	@Override
	public String toString() {
		return "Hotels [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", arpn=" + arpn + ", phoneNum1=" + phoneNum1
				+ ", phoneNum2=" + phoneNum2 + ", rating=" + rating
				+ ", email=" + email + ", fax=" + fax + "]";
	}
	private float rating;
	private String email;
	private String fax;
	
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getArpn() {
		return arpn;
	}
	public void setArpn(float arpn) {
		this.arpn = arpn;
	}
	public String getPhoneNum1() {
		return phoneNum1;
	}
	public void setPhoneNum1(String phoneNum1) {
		this.phoneNum1 = phoneNum1;
	}
	public String getPhoneNum2() {
		return phoneNum2;
	}
	public void setPhoneNum2(String phoneNum2) {
		this.phoneNum2 = phoneNum2;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	
	

}
